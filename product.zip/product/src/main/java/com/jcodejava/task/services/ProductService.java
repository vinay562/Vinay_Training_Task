package com.jcodejava.task.services;

import java.util.List;

import com.jcodejava.task.commands.ProductForm;
import com.jcodejava.task.domains.Product;

public interface ProductService {

    List<Product> listAll();

    Product getById(Long id);

    Product saveOrUpdate(Product product);

    void delete(Long id);

    Product saveOrUpdateProductForm(ProductForm productForm);
}
