package com.jcodejava.task.repositories;

import org.springframework.data.repository.CrudRepository;

import com.jcodejava.task.domains.Product;

public interface ProductRepository extends CrudRepository<Product, Long> {
}
