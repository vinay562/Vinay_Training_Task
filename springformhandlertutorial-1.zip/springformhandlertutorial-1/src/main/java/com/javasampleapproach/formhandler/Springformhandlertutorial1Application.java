package com.javasampleapproach.formhandler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springformhandlertutorial1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springformhandlertutorial1Application.class, args);
	}

}
