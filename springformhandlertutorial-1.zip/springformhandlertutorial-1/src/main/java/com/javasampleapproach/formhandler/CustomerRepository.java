package com.javasampleapproach.formhandler;

import org.springframework.data.repository.CrudRepository;
import com.javasampleapproach.formhandler.Customer;
 
public interface CustomerRepository extends CrudRepository<Customer, Long> {}