package com.jcoreava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringformhandlertutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringformhandlertutorialApplication.class, args);
	}

}
